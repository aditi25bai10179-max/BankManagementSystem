# Bank Management System with Fraud-Check Simulation

A small Java project demonstrating encapsulation, the Singleton pattern,
multithreading, custom exceptions, and JUnit testing through a simulated
bank that processes deposits, withdrawals, and transfers while screening
every transaction through a rule-based fraud detector.

## Project Objective

This project applies core Java concepts to a realistic problem:

- **Problem**: bank transactions must stay correct even when many are
  happening at once, and obviously risky transactions should be stopped
  before they touch an account balance.
- **Design**: a layered architecture separating domain models, the
  transaction orchestration layer, fraud rules, and audit logging.
- **Implementation**: thread-safe account operations, a Singleton bank
  registry, custom checked exceptions, and an `ExecutorService`-driven
  demo of concurrent transactions.
- **Evaluation**: JUnit 5 tests, including tests that specifically
  exercise concurrent access to prove balances stay correct.

## Architecture

```
com.bank
├── Main.java                     Entry point / demo scenarios
├── model/
│   ├── Account.java               Encapsulated, thread-safe balance
│   └── Customer.java               Customer identity + owned accounts
├── core/
│   ├── Bank.java                   Singleton registry of accounts & customers
│   └── TransactionManager.java     Orchestrates deposit/withdraw/transfer
├── fraud/
│   └── FraudDetector.java          Rule-based fraud checks (amount + velocity)
├── audit/
│   └── AuditLogger.java            Thread-safe, timestamped audit trail
└── exception/
    ├── BankException.java              Base checked exception
    ├── InsufficientFundsException.java
    ├── AccountNotFoundException.java
    └── FraudDetectedException.java
```

**Why this shape:** each package has one job. `model` only knows about
its own state and invariants (an account never goes negative). `core`
knows how to coordinate multiple accounts and never manipulates a
balance directly. `fraud` only evaluates risk and knows nothing about
persistence. `audit` only records what happened. This separation is
what lets you unit-test the fraud rules and the account math
independently, and it's the kind of separation-of-concerns a grader
will look for in the "architectural design" criterion.

## Concepts Demonstrated

| Concept | Where |
|---|---|
| Encapsulation | `Account` - private `balance`, mutated only through validated methods |
| Singleton pattern | `Bank.getInstance()` (eager holder), `AuditLogger.getInstance()` (double-checked locking) |
| Multithreading | `Main.runConcurrentTransfers`, `synchronized` methods on `Account`, ordered lock acquisition in `TransactionManager.transfer` to avoid deadlock |
| Custom exceptions | `exception` package, all extending `BankException` |
| Concurrent collections | `ConcurrentHashMap` in `Bank` and `FraudDetector`, `CopyOnWriteArrayList` in `AuditLogger` |
| Validation & error handling | Input checks in `Account`, `Customer`; checked exceptions surfaced to callers |
| Unit testing | `AccountTest`, `TransactionManagerTest` (JUnit 5), including two dedicated concurrency tests |

## Fraud Rules (simulation only, not a real model)

1. **Single-transaction ceiling** - any transaction ≥ $10,000 is blocked.
2. **Velocity check** - more than 3 transactions on the same account
   within a 2-second window is blocked (mimics bot/card-testing fraud).

## Building and Running

Requires JDK 17+ and Maven.

```bash
# Compile, run tests, and package
mvn clean package

# Run the demo
java -cp target/bank-management-system.jar com.bank.Main

# Run tests only
mvn test
```

## Sample Output (abridged)

```
--- Concurrent transfers on the same accounts ---
--- Final balances ---
Account{id='A1', owner='C1', balance=4600.00}
Account{id='A2', owner='C2', balance=1500.00}

--- Audit trail ---
[2026-09-17 10:02:11.201] (pool-1-thread-3) TRANSFER success: from=A1 to=A2 amount=10.00
...
```

## Possible Extensions

- Persist accounts to a file or embedded database instead of in-memory maps.
- Replace the fraud rules with a simple weighted scoring model.
- Add a REST layer (Spark/Javalin) so transactions can be triggered over HTTP.
- Track fraud false-positive/negative rates against a synthetic dataset for
  a more rigorous "evaluation" section.

## Version Control

Initialize with:

```bash
git init
git add .
git commit -m "Initial bank management system with fraud simulation"
```

Suggested `.gitignore` entries: `target/`, `*.class`, `.idea/`, `*.iml`.
