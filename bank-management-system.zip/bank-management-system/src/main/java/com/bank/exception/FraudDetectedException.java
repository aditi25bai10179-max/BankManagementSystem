package com.bank.exception;

/**
 * Thrown by the FraudDetector when a transaction matches one or more
 * fraud-risk rules and is blocked before it reaches the account balance.
 */
public class FraudDetectedException extends BankException {

    public FraudDetectedException(String reason) {
        super("Transaction blocked - suspected fraud: " + reason);
    }
}
