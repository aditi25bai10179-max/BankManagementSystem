package com.bank.exception;

/**
 * Base checked exception for all banking-domain errors.
 * Every custom exception in this system extends this class so callers
 * can catch a single type when they only care that "something in the
 * bank layer went wrong", or catch the specific subclass when they need
 * finer-grained handling.
 */
public class BankException extends Exception {

    public BankException(String message) {
        super(message);
    }

    public BankException(String message, Throwable cause) {
        super(message, cause);
    }
}
