package com.bank.exception;

/**
 * Thrown when a withdrawal or transfer is attempted for more than the
 * account's available balance.
 */
public class InsufficientFundsException extends BankException {

    public InsufficientFundsException(String accountId, double requested, double available) {
        super(String.format(
                "Insufficient funds in account %s: requested=%.2f, available=%.2f",
                accountId, requested, available));
    }
}
