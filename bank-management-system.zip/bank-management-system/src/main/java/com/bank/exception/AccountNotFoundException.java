package com.bank.exception;

/**
 * Thrown when an operation references an account id that does not exist
 * in the bank's records.
 */
public class AccountNotFoundException extends BankException {

    public AccountNotFoundException(String accountId) {
        super("No account found with id: " + accountId);
    }
}
