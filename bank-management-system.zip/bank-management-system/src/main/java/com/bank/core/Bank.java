package com.bank.core;

import com.bank.exception.AccountNotFoundException;
import com.bank.model.Account;
import com.bank.model.Customer;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The Bank represents the single, shared source of truth for all
 * accounts and customers in the system. There should only ever be one
 * Bank instance per running application, so it is implemented as a
 * Singleton using an eagerly-initialized static holder, which is
 * inherently thread-safe without needing explicit locking.
 */
public final class Bank {

    private static final class Holder {
        private static final Bank INSTANCE = new Bank();
    }

    private final Map<String, Account> accounts = new ConcurrentHashMap<>();
    private final Map<String, Customer> customers = new ConcurrentHashMap<>();

    private Bank() {
    }

    public static Bank getInstance() {
        return Holder.INSTANCE;
    }

    public Customer registerCustomer(Customer customer) {
        customers.put(customer.getCustomerId(), customer);
        return customer;
    }

    public Account openAccount(Account account) {
        accounts.put(account.getAccountId(), account);
        Customer owner = customers.get(account.getOwnerId());
        if (owner != null) {
            owner.linkAccount(account.getAccountId());
        }
        return account;
    }

    public Account getAccount(String accountId) throws AccountNotFoundException {
        Account account = accounts.get(accountId);
        if (account == null) {
            throw new AccountNotFoundException(accountId);
        }
        return account;
    }

    public Customer getCustomer(String customerId) {
        return customers.get(customerId);
    }

    public int accountCount() {
        return accounts.size();
    }

    /** Test/demo convenience: wipes all state so scenarios can start clean. */
    public void reset() {
        accounts.clear();
        customers.clear();
    }
}
