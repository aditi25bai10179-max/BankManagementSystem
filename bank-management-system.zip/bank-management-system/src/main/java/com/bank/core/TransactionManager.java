package com.bank.core;

import com.bank.audit.AuditLogger;
import com.bank.exception.AccountNotFoundException;
import com.bank.exception.BankException;
import com.bank.exception.FraudDetectedException;
import com.bank.exception.InsufficientFundsException;
import com.bank.fraud.FraudDetector;
import com.bank.model.Account;

/**
 * Coordinates deposits, withdrawals and transfers on top of the
 * {@link Bank} singleton. This is the layer that:
 * <ol>
 *   <li>Looks up the accounts involved.</li>
 *   <li>Runs the fraud check first, before any balance is touched.</li>
 *   <li>Delegates the actual balance mutation to {@link Account}, which
 *       is where the real thread-safety (per-account locking) lives.</li>
 *   <li>Writes an audit trail entry for every attempt, success or
 *       failure.</li>
 * </ol>
 *
 * <p>Multiple {@code TransactionManager} calls are expected to be
 * submitted concurrently (e.g. from an {@link java.util.concurrent.ExecutorService})
 * to simulate real-world concurrent banking activity; this class holds
 * no mutable state of its own; all shared state lives in {@link Bank},
 * {@link Account} and {@link AuditLogger}, each of which is responsible
 * for its own thread safety.
 */
public class TransactionManager {

    private final Bank bank;
    private final FraudDetector fraudDetector;
    private final AuditLogger auditLogger;

    public TransactionManager(Bank bank, FraudDetector fraudDetector, AuditLogger auditLogger) {
        this.bank = bank;
        this.fraudDetector = fraudDetector;
        this.auditLogger = auditLogger;
    }

    public void deposit(String accountId, double amount) throws BankException {
        Account account = bank.getAccount(accountId);
        try {
            fraudDetector.check(accountId, amount);
            account.deposit(amount);
            auditLogger.log(String.format("DEPOSIT success: account=%s amount=%.2f newBalance=%.2f",
                    accountId, amount, account.getBalance()));
        } catch (FraudDetectedException e) {
            auditLogger.log(String.format("DEPOSIT blocked: account=%s amount=%.2f reason=%s",
                    accountId, amount, e.getMessage()));
            throw e;
        }
    }

    public void withdraw(String accountId, double amount) throws BankException {
        Account account = bank.getAccount(accountId);
        try {
            fraudDetector.check(accountId, amount);
            account.withdraw(amount);
            auditLogger.log(String.format("WITHDRAW success: account=%s amount=%.2f newBalance=%.2f",
                    accountId, amount, account.getBalance()));
        } catch (FraudDetectedException e) {
            auditLogger.log(String.format("WITHDRAW blocked: account=%s amount=%.2f reason=%s",
                    accountId, amount, e.getMessage()));
            throw e;
        } catch (InsufficientFundsException e) {
            auditLogger.log(String.format("WITHDRAW failed: account=%s amount=%.2f reason=%s",
                    accountId, amount, e.getMessage()));
            throw e;
        }
    }

    /**
     * Transfers funds between two accounts. Locks are acquired on both
     * accounts in a fixed order (by account id, lexicographically) to
     * avoid the classic transfer-deadlock scenario where thread A holds
     * account X and waits for Y while thread B holds Y and waits for X.
     */
    public void transfer(String fromAccountId, String toAccountId, double amount) throws BankException {
        if (fromAccountId.equals(toAccountId)) {
            throw new IllegalArgumentException("Cannot transfer to the same account");
        }
        Account from = bank.getAccount(fromAccountId);
        Account to = bank.getAccount(toAccountId);

        Account first = fromAccountId.compareTo(toAccountId) < 0 ? from : to;
        Account second = fromAccountId.compareTo(toAccountId) < 0 ? to : from;

        try {
            fraudDetector.check(fromAccountId, amount);
            synchronized (first) {
                synchronized (second) {
                    from.withdraw(amount);
                    to.deposit(amount);
                }
            }
            auditLogger.log(String.format("TRANSFER success: from=%s to=%s amount=%.2f",
                    fromAccountId, toAccountId, amount));
        } catch (FraudDetectedException e) {
            auditLogger.log(String.format("TRANSFER blocked: from=%s to=%s amount=%.2f reason=%s",
                    fromAccountId, toAccountId, amount, e.getMessage()));
            throw e;
        } catch (InsufficientFundsException e) {
            auditLogger.log(String.format("TRANSFER failed: from=%s to=%s amount=%.2f reason=%s",
                    fromAccountId, toAccountId, amount, e.getMessage()));
            throw e;
        }
    }
}
