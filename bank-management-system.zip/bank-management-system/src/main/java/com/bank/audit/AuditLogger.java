package com.bank.audit;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Records an immutable, timestamped trail of every transaction attempt
 * (successful, rejected for insufficient funds, or blocked as fraud).
 *
 * <p>Implemented as a classic (non-Bank) Singleton: exactly one audit
 * trail should exist for the whole application, regardless of how many
 * threads are logging to it concurrently.
 *
 * <p>{@link CopyOnWriteArrayList} is used instead of a plain
 * {@code ArrayList} because writes are relatively infrequent compared to
 * a real production system's reads, and it gives us safe concurrent
 * iteration without needing to hand-roll synchronization for reads.
 */
public final class AuditLogger {

    private static final DateTimeFormatter TIMESTAMP_FORMAT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    private static volatile AuditLogger instance;

    private final List<String> entries = new CopyOnWriteArrayList<>();

    private AuditLogger() {
    }

    /** Double-checked locking so the singleton is safe under concurrent first-access. */
    public static AuditLogger getInstance() {
        if (instance == null) {
            synchronized (AuditLogger.class) {
                if (instance == null) {
                    instance = new AuditLogger();
                }
            }
        }
        return instance;
    }

    public void log(String message) {
        String timestamp = LocalDateTime.now().format(TIMESTAMP_FORMAT);
        String threadName = Thread.currentThread().getName();
        entries.add(String.format("[%s] (%s) %s", timestamp, threadName, message));
    }

    public List<String> getEntries() {
        return Collections.unmodifiableList(entries);
    }

    public void printAll() {
        entries.forEach(System.out::println);
    }

    /** Package/test-visible reset so unit tests don't leak state into each other. */
    public void clear() {
        entries.clear();
    }
}
