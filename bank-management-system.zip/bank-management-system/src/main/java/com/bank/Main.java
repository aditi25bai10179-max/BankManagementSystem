package com.bank;

import com.bank.audit.AuditLogger;
import com.bank.core.Bank;
import com.bank.core.TransactionManager;
import com.bank.exception.BankException;
import com.bank.fraud.FraudDetector;
import com.bank.model.Account;
import com.bank.model.Customer;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Entry point that wires the system together and demonstrates:
 * <ul>
 *   <li>Normal deposit/withdraw/transfer flow.</li>
 *   <li>A transaction blocked by the fraud detector (amount too large).</li>
 *   <li>A transaction rejected for insufficient funds.</li>
 *   <li>Several threads hammering the same account concurrently, to show
 *       that the final balance stays correct instead of drifting due to
 *       a race condition.</li>
 * </ul>
 */
public class Main {

    public static void main(String[] args) throws Exception {
        Bank bank = Bank.getInstance();
        FraudDetector fraudDetector = new FraudDetector();
        AuditLogger auditLogger = AuditLogger.getInstance();
        TransactionManager txManager = new TransactionManager(bank, fraudDetector, auditLogger);

        Customer alice = bank.registerCustomer(new Customer("C1", "Alice", "alice@example.com"));
        Customer bob = bank.registerCustomer(new Customer("C2", "Bob", "bob@example.com"));

        Account aliceAcc = bank.openAccount(new Account("A1", alice.getCustomerId(), 5000.0));
        Account bobAcc = bank.openAccount(new Account("A2", bob.getCustomerId(), 1000.0));

        System.out.println("--- Initial state ---");
        System.out.println(aliceAcc);
        System.out.println(bobAcc);

        System.out.println("\n--- Normal operations ---");
        safeRun(() -> txManager.deposit("A1", 200.0));
        safeRun(() -> txManager.withdraw("A2", 100.0));
        safeRun(() -> txManager.transfer("A1", "A2", 500.0));

        System.out.println("\n--- Fraud check: single transaction too large ---");
        safeRun(() -> txManager.withdraw("A1", 50_000.0));

        System.out.println("\n--- Insufficient funds ---");
        safeRun(() -> txManager.withdraw("A2", 1_000_000.0));

        System.out.println("\n--- Concurrent transfers on the same accounts ---");
        runConcurrentTransfers(txManager);

        System.out.println("\n--- Final balances ---");
        System.out.println(bank.getAccount("A1"));
        System.out.println(bank.getAccount("A2"));

        System.out.println("\n--- Audit trail ---");
        auditLogger.printAll();
    }

    /** Fires 10 concurrent $10 transfers from A1 to A2 to demonstrate thread-safe balance updates. */
    private static void runConcurrentTransfers(TransactionManager txManager) throws InterruptedException {
        int threadCount = 10;
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        CountDownLatch latch = new CountDownLatch(threadCount);

        for (int i = 0; i < threadCount; i++) {
            executor.submit(() -> {
                try {
                    txManager.transfer("A1", "A2", 10.0);
                } catch (BankException e) {
                    System.out.println("Concurrent transfer failed: " + e.getMessage());
                } finally {
                    latch.countDown();
                }
            });
        }

        latch.await(5, TimeUnit.SECONDS);
        executor.shutdown();
    }

    @FunctionalInterface
    private interface BankOperation {
        void run() throws BankException;
    }

    private static void safeRun(BankOperation operation) {
        try {
            operation.run();
            System.out.println("OK");
        } catch (BankException e) {
            System.out.println("Rejected: " + e.getMessage());
        }
    }
}
