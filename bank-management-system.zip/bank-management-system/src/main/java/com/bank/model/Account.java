package com.bank.model;

import com.bank.exception.InsufficientFundsException;

import java.util.Objects;

/**
 * Represents a single bank account.
 *
 * <p><b>Encapsulation:</b> the balance field is private and can only be
 * changed through {@link #deposit(double)} and {@link #withdraw(double)},
 * which validate their input before touching the balance.
 *
 * <p><b>Thread safety:</b> multiple {@link com.bank.core.TransactionManager}
 * threads may operate on the same account concurrently (e.g. two transfers
 * touching the same account at once). Every method that reads or mutates
 * {@code balance} is {@code synchronized} on the account instance itself,
 * so operations on the same account are serialized while operations on
 * different accounts can still run in parallel.
 */
public class Account {

    private final String accountId;
    private final String ownerId;
    private double balance;

    public Account(String accountId, String ownerId, double openingBalance) {
        if (openingBalance < 0) {
            throw new IllegalArgumentException("Opening balance cannot be negative");
        }
        this.accountId = Objects.requireNonNull(accountId, "accountId cannot be null");
        this.ownerId = Objects.requireNonNull(ownerId, "ownerId cannot be null");
        this.balance = openingBalance;
    }

    public String getAccountId() {
        return accountId;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public synchronized double getBalance() {
        return balance;
    }

    /**
     * Credits the account. Synchronized so concurrent deposits from
     * different threads never race on the {@code balance} field.
     */
    public synchronized void deposit(double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Deposit amount must be positive");
        }
        balance += amount;
    }

    /**
     * Debits the account after checking sufficient funds.
     * The check-then-act sequence is inside the synchronized block so no
     * other thread can slip in a withdrawal between the check and the
     * update (this is the classic race condition multithreaded banking
     * demos are built to expose).
     */
    public synchronized void withdraw(double amount) throws InsufficientFundsException {
        if (amount <= 0) {
            throw new IllegalArgumentException("Withdrawal amount must be positive");
        }
        if (amount > balance) {
            throw new InsufficientFundsException(accountId, amount, balance);
        }
        balance -= amount;
    }

    @Override
    public String toString() {
        return String.format("Account{id='%s', owner='%s', balance=%.2f}", accountId, ownerId, balance);
    }
}
