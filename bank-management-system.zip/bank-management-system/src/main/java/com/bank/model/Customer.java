package com.bank.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Represents a bank customer who can own one or more {@link Account}s.
 * Kept intentionally simple: identity + contact info + the list of
 * account ids that belong to them. All account balance logic lives in
 * {@link Account}, not here, to keep responsibilities separated.
 */
public class Customer {

    private final String customerId;
    private final String name;
    private final String email;
    private final List<String> accountIds = new ArrayList<>();

    public Customer(String customerId, String name, String email) {
        this.customerId = Objects.requireNonNull(customerId, "customerId cannot be null");
        this.name = Objects.requireNonNull(name, "name cannot be null");
        this.email = Objects.requireNonNull(email, "email cannot be null");
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    /** Returns an unmodifiable view so callers cannot mutate internal state directly. */
    public List<String> getAccountIds() {
        return Collections.unmodifiableList(accountIds);
    }

    public synchronized void linkAccount(String accountId) {
        accountIds.add(accountId);
    }

    @Override
    public String toString() {
        return String.format("Customer{id='%s', name='%s', accounts=%s}", customerId, name, accountIds);
    }
}
