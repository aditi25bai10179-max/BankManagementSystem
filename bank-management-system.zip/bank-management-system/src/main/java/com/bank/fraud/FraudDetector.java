package com.bank.fraud;

import com.bank.exception.FraudDetectedException;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Applies a small set of rule-based heuristics to decide whether a
 * transaction looks suspicious. This is a simulation for coursework
 * purposes, not a real fraud model - the rules are deliberately simple
 * and explainable rather than statistically tuned.
 *
 * <p>Rules applied, in order:
 * <ol>
 *   <li>Single-transaction ceiling - any single transaction above
 *       {@link #LARGE_TRANSACTION_THRESHOLD} is flagged.</li>
 *   <li>Velocity check - more than {@link #MAX_TRANSACTIONS_PER_WINDOW}
 *       transactions from the same account within
 *       {@link #WINDOW_MILLIS} is flagged as "rapid-fire" activity,
 *       which is how card-testing / bot fraud typically looks.</li>
 * </ol>
 *
 * <p>Thread safety: multiple {@code TransactionManager} threads call
 * {@link #check(String, double)} concurrently for different accounts,
 * so the per-account transaction history is kept in a
 * {@link ConcurrentHashMap} guarding small synchronized per-account
 * counters rather than a single global lock.
 */
public class FraudDetector {

    private static final double LARGE_TRANSACTION_THRESHOLD = 10_000.0;
    private static final int MAX_TRANSACTIONS_PER_WINDOW = 3;
    private static final long WINDOW_MILLIS = 2_000L;

    private final Map<String, AccountActivity> activityByAccount = new ConcurrentHashMap<>();

    /**
     * Evaluates a proposed transaction and throws if it looks fraudulent.
     * Callers are expected to run this check before calling
     * {@code Account.withdraw}/{@code deposit} so a blocked transaction
     * never touches the balance.
     */
    public void check(String accountId, double amount) throws FraudDetectedException {
        if (amount >= LARGE_TRANSACTION_THRESHOLD) {
            throw new FraudDetectedException(
                    String.format("amount %.2f exceeds single-transaction limit of %.2f",
                            amount, LARGE_TRANSACTION_THRESHOLD));
        }

        AccountActivity activity = activityByAccount.computeIfAbsent(accountId, id -> new AccountActivity());
        if (activity.registerAndCheckVelocity()) {
            throw new FraudDetectedException(
                    String.format("more than %d transactions on account %s within %dms",
                            MAX_TRANSACTIONS_PER_WINDOW, accountId, WINDOW_MILLIS));
        }
    }

    /** Tracks recent transaction timestamps for a single account. */
    private static final class AccountActivity {
        private long windowStart = 0L;
        private int countInWindow = 0;

        /** Returns true if this call pushes the account over the velocity limit. */
        synchronized boolean registerAndCheckVelocity() {
            long now = System.currentTimeMillis();
            if (now - windowStart > WINDOW_MILLIS) {
                windowStart = now;
                countInWindow = 1;
                return false;
            }
            countInWindow++;
            return countInWindow > MAX_TRANSACTIONS_PER_WINDOW;
        }
    }
}
