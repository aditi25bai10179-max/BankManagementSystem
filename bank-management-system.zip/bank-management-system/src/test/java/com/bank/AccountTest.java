package com.bank;

import com.bank.exception.InsufficientFundsException;
import com.bank.model.Account;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class AccountTest {

    private Account account;

    @BeforeEach
    void setUp() {
        account = new Account("ACC-TEST", "OWNER-TEST", 100.0);
    }

    @Test
    void depositIncreasesBalance() {
        account.deposit(50.0);
        assertEquals(150.0, account.getBalance(), 0.0001);
    }

    @Test
    void withdrawDecreasesBalance() throws InsufficientFundsException {
        account.withdraw(40.0);
        assertEquals(60.0, account.getBalance(), 0.0001);
    }

    @Test
    void withdrawMoreThanBalanceThrows() {
        assertThrows(InsufficientFundsException.class, () -> account.withdraw(500.0));
        // balance must be unchanged after a rejected withdrawal
        assertEquals(100.0, account.getBalance(), 0.0001);
    }

    @Test
    void depositRejectsNonPositiveAmount() {
        assertThrows(IllegalArgumentException.class, () -> account.deposit(0.0));
        assertThrows(IllegalArgumentException.class, () -> account.deposit(-10.0));
    }

    @Test
    void withdrawRejectsNonPositiveAmount() {
        assertThrows(IllegalArgumentException.class, () -> account.withdraw(0.0));
        assertThrows(IllegalArgumentException.class, () -> account.withdraw(-10.0));
    }

    @Test
    void constructorRejectsNegativeOpeningBalance() {
        assertThrows(IllegalArgumentException.class, () -> new Account("X", "Y", -1.0));
    }

    /**
     * Concurrency test: fire 100 deposits of $1 from 20 threads at the
     * same account and confirm the final balance reflects every single
     * deposit. If {@code deposit()} were not synchronized, some updates
     * would be lost to a race condition and this would fail intermittently.
     */
    @Test
    void concurrentDepositsAreThreadSafe() throws InterruptedException {
        int threadCount = 20;
        int depositsPerThread = 5;
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        CountDownLatch latch = new CountDownLatch(threadCount);

        for (int i = 0; i < threadCount; i++) {
            executor.submit(() -> {
                for (int j = 0; j < depositsPerThread; j++) {
                    account.deposit(1.0);
                }
                latch.countDown();
            });
        }

        assertTrue(latch.await(5, TimeUnit.SECONDS), "Threads did not finish in time");
        executor.shutdown();

        double expected = 100.0 + (threadCount * depositsPerThread);
        assertEquals(expected, account.getBalance(), 0.0001);
    }
}
