package com.bank;

import com.bank.audit.AuditLogger;
import com.bank.core.Bank;
import com.bank.core.TransactionManager;
import com.bank.exception.BankException;
import com.bank.exception.FraudDetectedException;
import com.bank.exception.InsufficientFundsException;
import com.bank.fraud.FraudDetector;
import com.bank.model.Account;
import com.bank.model.Customer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class TransactionManagerTest {

    private Bank bank;
    private TransactionManager txManager;

    @BeforeEach
    void setUp() {
        bank = Bank.getInstance();
        bank.reset();
        AuditLogger.getInstance().clear();

        bank.registerCustomer(new Customer("C1", "Alice", "alice@example.com"));
        bank.registerCustomer(new Customer("C2", "Bob", "bob@example.com"));
        bank.openAccount(new Account("A1", "C1", 1000.0));
        bank.openAccount(new Account("A2", "C2", 500.0));

        txManager = new TransactionManager(bank, new FraudDetector(), AuditLogger.getInstance());
    }

    @AfterEach
    void tearDown() {
        bank.reset();
    }

    @Test
    void depositIncreasesBalance() throws BankException {
        txManager.deposit("A1", 100.0);
        assertEquals(1100.0, bank.getAccount("A1").getBalance(), 0.0001);
    }

    @Test
    void withdrawInsufficientFundsThrows() {
        assertThrows(InsufficientFundsException.class, () -> txManager.withdraw("A2", 10_000.0));
    }

    @Test
    void largeTransactionIsBlockedAsFraud() {
        assertThrows(FraudDetectedException.class, () -> txManager.withdraw("A1", 999_999.0));
    }

    @Test
    void rapidFireTransactionsTriggerVelocityFraudRule() {
        assertThrows(FraudDetectedException.class, () -> {
            // fraud detector's default velocity limit is 3 per 2-second window
            for (int i = 0; i < 5; i++) {
                txManager.deposit("A1", 10.0);
            }
        });
    }

    @Test
    void transferMovesFundsBetweenAccounts() throws BankException {
        txManager.transfer("A1", "A2", 200.0);
        assertEquals(800.0, bank.getAccount("A1").getBalance(), 0.0001);
        assertEquals(700.0, bank.getAccount("A2").getBalance(), 0.0001);
    }

    @Test
    void transferToSameAccountRejected() {
        assertThrows(IllegalArgumentException.class, () -> txManager.transfer("A1", "A1", 10.0));
    }

    /**
     * Concurrency test: 20 threads each transfer $10 from A1 to A2 at the
     * same time. Total balance across both accounts must be conserved
     * (nothing created or destroyed) even under concurrent access -
     * this is the key correctness property for a banking system.
     */
    @Test
    void concurrentTransfersPreserveTotalBalance() throws InterruptedException {
        double initialTotal = bank.getAccount("A1").getBalance() + bank.getAccount("A2").getBalance();

        int threadCount = 20;
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        CountDownLatch latch = new CountDownLatch(threadCount);

        for (int i = 0; i < threadCount; i++) {
            executor.submit(() -> {
                try {
                    txManager.transfer("A1", "A2", 1.0);
                } catch (BankException ignored) {
                    // fraud velocity limits may legitimately reject some of these;
                    // what matters is that every accepted transfer keeps the total intact
                } finally {
                    latch.countDown();
                }
            });
        }

        assertTrue(latch.await(5, TimeUnit.SECONDS), "Threads did not finish in time");
        executor.shutdown();

        double finalTotal = bank.getAccount("A1").getBalance() + bank.getAccount("A2").getBalance();
        assertEquals(initialTotal, finalTotal, 0.0001);
    }
}
